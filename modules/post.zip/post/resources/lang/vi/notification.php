
<?php
return [
    'no_category' => "Không tìm thấy danh mục để sửa",
    'update_status' => "Đã cập nhật trạng thái",
    'error' => 'Đã có lỗi xảy ra',
    'first_category' => 'Vui lòng thêm danh mục trước',
    'post_add' => 'Đã thêm bài viết',
    'title' => 'Chưa nhập tiêu đề',
    'slug' => 'Chưa nhập liên kết tĩnh',
    'slug_unique' => 'Liên kết tĩnh bị trùng',
    'content_post' => 'Chưa nhập nội dung bài viết',
    'category_id' => 'Chưa chọn danh mục',
    'image' => 'Chưa chọn hình ảnh',
    'create_success' => 'Tạo mới dữ liệu thành công',
    'delete_success' => 'Xóa dữ liệu thành công',
    'update_success' => 'Đã cập nhập dữ liệu'
];
