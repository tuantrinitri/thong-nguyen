<?php
return [
    'no_category' => "No catalog found to correct",
    'update_status' => "Status updated",
    'error' => 'An error has occurred',
    'first_category' => 'Please add a category first',
    'post_add' => 'Added article',
    'title' => 'No title ',
    'slug' => 'No slug',
    'slug_unique' => 'Static links are duplicated',
    'conten_post' => 'No content',
    'category_id' => 'No category selected',
    'image' => 'No image',
    'create_success' => 'Create success',
    'delete_success' => 'Delete success',
    'update_success' => 'Update success'
];
