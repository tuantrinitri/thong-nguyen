<?php

return [
    [
        'name' => 'post.admin.index',
        'title' => 'Quản lý bài viết',
        'description' => 'Quản lý tât cả các thao tác với module bài viết',
    ],

];