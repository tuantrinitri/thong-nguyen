<?php

namespace Modules\Post\Repositories\Interfaces;

use Core\Supports\Repositories\Interfaces\BaseInterface;
use Modules\Post\Models\Post;

interface PostInterface extends BaseInterface
{
}
