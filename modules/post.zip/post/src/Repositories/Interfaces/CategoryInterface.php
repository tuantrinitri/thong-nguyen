<?php

namespace Modules\Post\Repositories\Interfaces;

use Core\Supports\Repositories\Interfaces\BaseInterface;


interface CategoryInterface extends BaseInterface
{
}
